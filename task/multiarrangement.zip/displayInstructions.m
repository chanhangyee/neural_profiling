function displayInstructions(img,waitTime)
% SIMPLE_GUI2 Select a data set from the pop-up menu, then
% click one of the plot-type push buttons. Clicking the button
% plots the selected data in the axes.

%  Create and then hide the UI as it is being constructed.
dialogClosed = false;

lbwh = get(0,'ScreenSize');
f = figure('WindowStyle','modal','MenuBar','none','NumberTitle','off','Resize','off','Units','pixels','Position',[0 0 lbwh(3:4)]);
a = axes();

axis(a,'equal','off');
set(f,'Color',[.9 .9 .9]);
axis(a,[0 1200 0 800]);
set(a,'YDir','reverse'); % y axis points down (for image display)

% Construct the components.

hbutton    = uicontrol('Style','pushbutton',...
             'Enable','off','String','Wait','Position',[315,220,70,25],...
             'Callback',@done_Callback);

% Assign the a name to appear in the window title.
set(f,'Name','Instruction');

imText = image('XData',0,'YData',0,'CData',img.image);
set(imText,'AlphaData',img.alpha); 

% Initialize the UI.
% Change units to normalized so components resize automatically.
set(hbutton,'Units','normalized','Position',[0.4,0.03,0.2,0.06]);

  % Push button callbacks. Each callback plots current_data in the
  % specified plot type.

  function done_Callback(source,eventdata) 
  % Display surf plot of the currently selected data.
    dialogClosed = true;
  end

drawnow;
pause(waitTime);
set(hbutton,'Enable','on');
set(hbutton,'String','OK');

while ~dialogClosed
    a = waitforbuttonpress;
    pause(0.5);
end
close(f)
end