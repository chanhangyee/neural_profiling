% START_performMultiarrangement
clear; close all hidden;

%% get subject initials                                         
options.subjectInitials=inputdlg('Subject number:');
options.subjectInitials=options.subjectInitials{1};
options.axisUnits='normalized'; % images resized

options.analysisFigs=false;
options.maxSessionLength_min=15;
options.waitTime=20;

image_files = {'abercrombie-fitch','adobe','apple','axe','beats','campina','dell','disney','durex','heineken','kelloggs','microsoft','pampers','redbull'}; 
instruction_files = {'instruction'};
instruction_strings = {'Please arrange the brands according to their brand image similarity'};

order = [[1 2 3 4];[1 2 4 3];[1 3 2 4];[1 3 4 2];[1 4 2 3];[1 4 3 2]];
group = mod(str2num(options.subjectInitials),6)+1;

for i=1:numel(image_files),
    s = strcat('brand',filesep,image_files(i),'.png');
    [X map alpha] = imread(s{1});
    stimuli(i).image = X;
    stimuli(i).alpha = alpha;
end

for i=1:numel(instruction_files),
    s = strcat('instruction',filesep,instruction_files(i),'.png');
    [X map alpha] = imread(s{1});
    instruction(i).image = X;
    instruction(i).alpha = alpha;
end

%% load stimuli
stimuli=stimuli(1:numel(stimuli));

%% prepare output directory
files=dir(['S',options.subjectInitials,'_similarityJudgementData']);
if size(files,1)==0
    % folder 'similarityJudgementData' doesn't exist within current folder: make it
    mkdir(['S',options.subjectInitials,'_similarityJudgementData']);  
end
cd(['S',options.subjectInitials,'_similarityJudgementData']);

options.sessionI=1;  

%% administer session
options.dateAndTime_start=clock;

displayInstructions(instruction(1),options.waitTime);

% MULTI-ARRANGEMENT (MA)
[estimate_dissimMat_ltv_MA,simulationResults_ignore,story_MA]=simJudgmentByMultiArrangement_circArena_liftTheWeakest(stimuli,instruction_strings(1),options);


%% save experimental data from the current subject
save(['S',options.subjectInitials,'_',dateAndTimeStringNoSec_nk,'_workspace']);


%% display representational dissimilarity matrix (RDM)
% showSimmats(estimate_dissimMat_ltv_MA);
% addHeadingAndPrint('multiple-trial RDM','figures');


%% plot stimuli in multidimensional-scaling (MDS) arrangement
% criterion='metricstress';
% [pats_mds_2D,stress,disparities]=mdscale(estimate_dissimMat_ltv_MA,2,'criterion',criterion);
% 
% pageFigure(400); subplot(2,1,1); 
% drawImageArrangement(stimuli,pats_mds_2D,1,[1 1 1]);
% title({'\fontsize{14}stimulus images in MDS arrangement\fontsize{11}',[' (',criterion,')']});
% shepardPlot(estimate_dissimMat_ltv_MA,disparities,pdist(pats_mds_2D),[400 2 1 2],['\fontsize{14}shepard plot\fontsize{11}',' (',criterion,')']);
% addHeadingAndPrint('multiple-trial MDS plot','figures');
% 

%% revert to original directory

lbwh = get(0,'ScreenSize');
f = figure('WindowStyle','modal','MenuBar','none','NumberTitle','off','Resize','off','Units','pixels','Position',[0 0 lbwh(3:4)]);

uiwait(msgbox({'You have completed the experiment.' 'Thank you for your participation!'},'modal'));
close(f);

cd('..');